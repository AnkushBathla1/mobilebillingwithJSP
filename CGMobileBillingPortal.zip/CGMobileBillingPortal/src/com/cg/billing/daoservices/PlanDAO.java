package com.cg.billing.daoservices;
import java.util.List;
import com.cg.billing.beans.Plan;
public interface PlanDAO {
	public Plan findPlan(int planID);
    public Plan savePlan(Plan plan);
	public Plan updatePlan(Plan plan);
	public List<Plan> findAllPlanDetails();
}
