package com.cg.billing.daoservices;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.billing.beans.PostpaidAccount;

public class PostpaidAccountDAOImpl implements PostpaidAccountDAO{
	EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public PostpaidAccount findPostPaidAccount(long mobileNo) {
		return entityManagerFactory.createEntityManager().find(PostpaidAccount.class, mobileNo);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<PostpaidAccount> findAllPostpaidAccounts() {
		Query query =entityManagerFactory.createEntityManager().createQuery("from PostpaidAccount p");
		return query.getResultList();
	}
	@Override
	public PostpaidAccount savePostpaidAccount(PostpaidAccount postPaidAccount) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(postPaidAccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		return postPaidAccount;
	}
	@Override
	public PostpaidAccount updatePostpaidAccount(PostpaidAccount postPaidAccount) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(postPaidAccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		return postPaidAccount;
	}
	@Override
	public boolean removePostpaidAccountDetails(long mobileNo) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		PostpaidAccount postpaidAccount=entityManager.find(PostpaidAccount.class,mobileNo);
		entityManager.getTransaction().begin();
		entityManager.remove(postpaidAccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
}
