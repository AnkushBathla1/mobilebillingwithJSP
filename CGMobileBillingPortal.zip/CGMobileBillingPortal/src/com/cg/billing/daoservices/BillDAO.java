package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.Bill;

public interface BillDAO {
	 
	public Bill saveBill(Bill bill);
	public List<Bill> findAllBills(long mobileNo);
	public Bill findParticularBill(long mobileNo,String billMonth);
}
