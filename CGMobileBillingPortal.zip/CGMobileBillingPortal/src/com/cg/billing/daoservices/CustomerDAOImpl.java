package com.cg.billing.daoservices;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.billing.beans.Customer;

public class CustomerDAOImpl implements CustomerDAO{
	EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Customer saveCustomer(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer;
	}
	@Override
	public Customer updateCustomer(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer;
	}
	@Override
	public Customer findCustomer(int customerID) {
	    return entityManagerFactory.createEntityManager().find(Customer.class, customerID);
	}
	@Override
	public boolean removeCustomer(int customerID) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Customer customer=entityManager.find(Customer.class, customerID);
		entityManager.getTransaction().begin();
		entityManager.remove(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> findAllCustomer() {
		Query query =entityManagerFactory.createEntityManager().createQuery("from Customer c");
		return query.getResultList();
	}
}
