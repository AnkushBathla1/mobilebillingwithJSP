package com.cg.billing.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.PostpaidAccount;
public class BillDaoImpl implements BillDAO{
	EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("JPA-PU");
    PostpaidAccountDAO postpaidAccountDAO=new PostpaidAccountDAOImpl();
	public Bill saveBill(Bill bill) {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
	entityManager.getTransaction().begin();
	entityManager.persist(bill);
	entityManager.getTransaction().commit();
	entityManager.close();
	return bill;}
    @SuppressWarnings("unchecked")
	@Override
	public List<Bill> findAllBills(long mobileNo) {
		PostpaidAccount postpaidAccount=entityManagerFactory.createEntityManager().find(PostpaidAccount.class, mobileNo);
		System.out.println("######"+mobileNo);
		return entityManagerFactory.createEntityManager().createQuery("from Bill t where t. postpaidAccount="+mobileNo).getResultList();
	}
    @Override
	public Bill findParticularBill(long mobileNo,String billMonth) {
    	return (Bill) entityManagerFactory.createEntityManager().createQuery("from Bill t where  t.postpaidAccount =" +mobileNo+" and billMonth ='"+billMonth+"'").getSingleResult();
		}
	}

