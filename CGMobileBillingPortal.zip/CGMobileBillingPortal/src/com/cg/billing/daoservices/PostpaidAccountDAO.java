package com.cg.billing.daoservices;
import java.util.List;
import com.cg.billing.beans.PostpaidAccount;
public interface PostpaidAccountDAO {
	public PostpaidAccount savePostpaidAccount(PostpaidAccount postPaidAccount);
	public PostpaidAccount updatePostpaidAccount(PostpaidAccount postPaidAccount);
	public PostpaidAccount findPostPaidAccount(long mobileNo);
	public List<PostpaidAccount> findAllPostpaidAccounts();
	public boolean removePostpaidAccountDetails(long mobileNo);

}
