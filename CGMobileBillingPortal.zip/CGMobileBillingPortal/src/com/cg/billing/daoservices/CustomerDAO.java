package com.cg.billing.daoservices;
import java.util.List;
import com.cg.billing.beans.Customer;
public interface CustomerDAO {
	public Customer saveCustomer(Customer customer); 
	public Customer updateCustomer(Customer customer);
	public Customer findCustomer(int customerID);
	public List<Customer> findAllCustomer();
	public boolean removeCustomer(int customerID);
}
