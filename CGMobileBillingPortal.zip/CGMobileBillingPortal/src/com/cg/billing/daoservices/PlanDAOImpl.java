package com.cg.billing.daoservices;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.billing.beans.Plan;
public class PlanDAOImpl implements PlanDAO {
	EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public List<Plan> findAllPlanDetails(){
		return entityManagerFactory.createEntityManager().createQuery("from Plan p").getResultList();
	}
    @Override
	public Plan savePlan(Plan plan) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(plan);
		entityManager.getTransaction().commit();
		entityManager.close();
		return plan;
	}
	@Override
	public Plan updatePlan(Plan plan) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(plan);
		entityManager.getTransaction().commit();
		entityManager.close();
		return plan;
	}
	@Override
	public Plan findPlan(int planID) {
		return entityManagerFactory.createEntityManager().find(Plan.class, planID);
	}
}
