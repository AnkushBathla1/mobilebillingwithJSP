package com.cg.billing.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

/**
 * Servlet implementation class CreatePlanServlet
 */
@WebServlet("/CreatePlanServlet")
public class CreatePlanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private BillingServices services;
	public void init()throws ServletException{
		services=new BillingServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=null;
		int monthlyRental=Integer.parseInt(request.getParameter("monthlyRental"));
		int freeLocalSMS=Integer.parseInt(request.getParameter("freeLocalSMS"));
		int freeLocalCalls=Integer.parseInt(request.getParameter("freeLocalCalls")); 
		int freeStdSMS=Integer.parseInt(request.getParameter("freeStdSMS"));
		int freeStdCalls=Integer.parseInt(request.getParameter("freeStdCalls"));
		int freeInternetDataUsageUnits=Integer.parseInt(request.getParameter("freeInternetDataUsageUnits"));
		float localSMSRate=Float.parseFloat(request.getParameter("localSMSRate"));
		float localCallRate=Float.parseFloat(request.getParameter("localCallRate"));
		float stdCallRate=Float.parseFloat(request.getParameter("stdCallRate"));
		float stdSMSRate =Float.parseFloat(request.getParameter("stdSMSRate"));
		float internetDataUsageRate=Float.parseFloat(request.getParameter(" internetDataUsage"));
		String planName=request.getParameter("planName");
		String planCircle=request.getParameter("planCircle");
		int planID=services.createPlan(monthlyRental, freeLocalCalls, freeStdCalls, freeLocalSMS, freeStdSMS, freeInternetDataUsageUnits, localCallRate, stdCallRate, localSMSRate, stdSMSRate, internetDataUsageRate, planCircle, planName);
		dispatcher=request.getRequestDispatcher("ResultCreatePlan.jsp");
		request.setAttribute("planID",planID);
		dispatcher.forward(request, response);
	}
	@Override
	public void destroy() {
		services=null;
	}
}